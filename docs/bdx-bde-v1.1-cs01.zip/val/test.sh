#
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExample.xml
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExampleFailSyntax.xml
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExampleFailModel.xml
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExampleExtension.xml
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExampleDecrypt.xml
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExampleMultipleToPartyXMLEnc1.xml
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExampleSignedNotFinal.xml
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExampleSignedFinal.xml
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExampleSignedNotFinalAdditional.xml
sh validate.sh ../xsd/BDE-Envelope-1.1.xsd simpleExampleSignedFinalAdditionalFail.xml
