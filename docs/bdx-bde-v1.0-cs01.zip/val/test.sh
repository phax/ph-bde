#
sh validate.sh ../xsd/BDE-Envelope-1.0.xsd simpleExample.xml
sh validate.sh ../xsd/BDE-Envelope-1.0.xsd simpleExampleFailSyntax.xml
sh validate.sh ../xsd/BDE-Envelope-1.0.xsd simpleExampleFailModel.xml
sh validate.sh ../xsd/BDE-Envelope-1.0.xsd simpleExampleExtension.xml
sh validate.sh ../xsd/BDE-Envelope-1.0.xsd simpleExampleSignedNotFinal.xml
sh validate.sh ../xsd/BDE-Envelope-1.0.xsd simpleExampleSignedFinal.xml
sh validate.sh ../xsd/BDE-Envelope-1.0.xsd simpleExampleSignedNotFinalAdditional.xml
sh validate.sh ../xsd/BDE-Envelope-1.0.xsd simpleExampleSignedFinalAdditionalFail.xml
