This forms part of the package of the DocBook XML publishing environment
and methodology found linked from http://docs.oasis-open.org/templates/

The contents of this directory are modified from
http://www.oasis-open.org/spectools/css/ as of
2006-02-03.
